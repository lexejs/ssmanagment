﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace xlsAsXmlReader
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void Form1_Load(object sender, EventArgs e)
		{

			var db = new ssmDataContext();
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.Load("book.xml");
			var nodes = xmlDocument.ChildNodes[xmlDocument.ChildNodes.Count - 1].ChildNodes[3].ChildNodes[0].ChildNodes;

			string groupName = "", itemName = "", itemDetail = "";
			foreach (XmlElement node in nodes)
			{
				if (node.Name.ToLower() == "row" && node.ChildNodes.Count < 4 && node.ChildNodes.Count > 0)
				{
					switch (node.ChildNodes.Count)
					{
						case 1:
							itemDetail = node.ChildNodes[0].InnerText;
							break;
						case 2:
							itemName = node.ChildNodes[0].InnerText;
							itemDetail = node.ChildNodes[1].InnerText;
							break;
						case 3:
							groupName = node.ChildNodes[0].InnerText;
							itemName = node.ChildNodes[1].InnerText;
							itemDetail = node.ChildNodes[2].InnerText;
							break;
					}
					var newGroup = db.groups.Where(g => g.name == groupName).FirstOrDefault();
					if (newGroup == null)
					{
						if (!String.IsNullOrEmpty(groupName))
						{
							newGroup = new group() {name = groupName};
							db.groups.InsertOnSubmit(newGroup);
							db.SubmitChanges();
						}
					}
					item newItem = new item() { name = itemName + " " + itemDetail,groupId = newGroup.id};
					db.items.InsertOnSubmit(newItem);
					db.SubmitChanges();


				}

			}
			//xmlDoc.LoadXml(
			//  xmlDocument.ChildNodes[xmlDocument.ChildNodes.Count - 1].ChildNodes[3].ChildNodes[0].ChildNodes);
		}
	}
}
